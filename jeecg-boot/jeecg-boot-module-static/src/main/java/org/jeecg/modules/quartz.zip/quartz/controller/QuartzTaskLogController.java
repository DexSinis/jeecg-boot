package com.yewyw.module.quartz.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 定时任务执行日志表 前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-07-08
 */
@Controller
@RequestMapping("/quartzTaskLog")
public class QuartzTaskLogController {

}

