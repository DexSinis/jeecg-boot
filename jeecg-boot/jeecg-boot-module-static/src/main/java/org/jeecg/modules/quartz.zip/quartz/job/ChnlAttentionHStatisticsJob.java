package com.yewyw.module.quartz.job;

import com.yewyw.module.statistics.service.ChnlAttentionHService;
import com.yewyw.util.date.ZxDateUtils;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;

/**
 * 定时任务统计每2小时的渠道数据（按小时统计）
 */
@Slf4j
public class ChnlAttentionHStatisticsJob implements Job {


    @Resource
    private ChnlAttentionHService chnlAttentionHService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        log.error(String.format("ChnlAttentionHStatisticsJob >>>>开始时间:" + ZxDateUtils.now()));
//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        Date after = calendar.getTime();
        calendar.set(Calendar.HOUR_OF_DAY,calendar.get(Calendar.HOUR_OF_DAY)-2);
        Date before = calendar.getTime();

        chnlAttentionHService.refreshChnlAttentionHByTime(before,after);

        log.error("ChnlAttentionHStatisticsJob >>>>结束时间:{}",ZxDateUtils.now());
    }


//    public static void main(String[] args){
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(new Date());
//        System.out.println("当前小时======::"+((Integer)(new Date().getHours())).toString());
//        System.out.println("calendar.getTime()当前时间======::"+calendar.getTime().getTime());
//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        calendar.set(Calendar.HOUR_OF_DAY,0);
//        calendar.set(Calendar.MINUTE,0);
//        calendar.set(Calendar.SECOND,0);
//        Date before = calendar.getTime();
//        System.out.println("calendar.get(Calendar.HOUR_OF_DAY)======::"+calendar.getTime().getTime());
//        log.info("ConsulterDStatisticsJob >>>>开始时间::[{};{}]",df.format(before));
//        calendar.set(Calendar.HOUR_OF_DAY,calendar.get(Calendar.HOUR_OF_DAY)-2);
//        log.info("ConsulterDStatisticsJob >>>>减时后时间::[{};{}]",df.format(calendar.getTime()));
//        System.out.println("calendar.getTime()当前时间减2小时======::"+before.getHours());
//        calendar.set(Calendar.HOUR_OF_DAY,23);
//        calendar.set(Calendar.MINUTE,59);
//        calendar.set(Calendar.SECOND,59);
//        Date after = calendar.getTime();
//
//        log.info("ConsulterDStatisticsJob >>>>开始时间::[{};{}]",df.format(before),df.format(after));
//        log.info("ConsulterDStatisticsJob >>>>结束时间:{}",df.format(after));
//    }

}
