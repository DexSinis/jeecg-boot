package com.yewyw.module.quartz.job;

import com.yewyw.module.consulter.service.ConsulterService;
import com.yewyw.module.statistics.service.PersUserDService;
import com.yewyw.util.date.ZxDateUtils;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import javax.annotation.Resource;
import java.util.Map;

/**
 * 定时任务统计用户数据
 */
@Slf4j
public class ConsulterDStatisticsJob implements Job {


    @Resource
    private ConsulterService consulterService;

    @Resource
    private PersUserDService persUserDService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        log.error(String.format("ConsulterDStatisticsJob >>>>开始时间:" + ZxDateUtils.now()));
        Map consulter = consulterService.findMaxConsulterId();
        Integer maxConsulterId = (Integer)consulter.get("id");
        Integer beforeConsulterId = 0;
        Integer afterConsulterId = 0;
        boolean flag = persUserDService.clearAllConsulterAnalysis();
        if(!flag){
            return;
        }
        for (int i = 0; i < maxConsulterId; i = i + 200000) {
            beforeConsulterId = i;
            afterConsulterId = i + 200000;
            if(afterConsulterId>maxConsulterId){
                afterConsulterId = maxConsulterId;
            }
            persUserDService.insertconsulterDForJob(beforeConsulterId.toString(),afterConsulterId.toString());
            if(afterConsulterId>=maxConsulterId){
                break;
            }
        }
        log.error("ConsulterDStatisticsJob >>>>结束时间:{}",ZxDateUtils.now());
    }


//    public static void main(String[] args) {
//        Integer maxConsulterId = 4017298;
//        Integer beforeConsulterId = 0;
//        Integer afterConsulterId = 0;
//        for (int i = 0; i < maxConsulterId; i = i + 200000) {
//            beforeConsulterId = i;
//            afterConsulterId = i + 200000;
//            if(afterConsulterId>maxConsulterId){
//                afterConsulterId = maxConsulterId;
//            }
//            System.out.println("before======::" + beforeConsulterId);
//            System.out.println("afterConsulterId======::" + afterConsulterId);
//            if(afterConsulterId>=maxConsulterId){
//                break;
//            }
//        }
//
//    }

}
