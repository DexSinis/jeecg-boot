package com.yewyw.module.quartz.job;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yewyw.constants.CommonConstant;
import com.yewyw.exception.InterfaceZxException;
import com.yewyw.module.quartz.entity.QuartzJob;
import com.yewyw.module.statistics.entity.OrderDtlD;
import com.yewyw.module.statistics.service.OrderDtlDService;
import com.yewyw.util.date.DateUtil;
import com.yewyw.util.date.LocalDateTimeUtil;
import com.yewyw.util.date.ZxDateUtils;
import com.yewyw.util.reflect.oConvertUtils;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
public class OrderDtlDStatisticsJob implements Job {

//    private static final Integer beforeDay = 0;

    /**
     * 若参数变量名修改 QuartzJobController中也需对应修改
     */
    private String parameter;



    @Resource
    private OrderDtlDService orderDtlDService;

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        log.error(String.format("OrderDtlDStatisticsJob >>>>开始时间:" + ZxDateUtils.now(), this.parameter));

//        if(1==1){
//            return;
//        }
        //统计前几天的数据 前三天数据把30改为2
        for (int i = -1; i <0 ; i++) {
            if(this.clearOrderEvaluationDAnalysis(i)){
                this.orderDtlDAnalysis(i);
            }
        }

        log.error(String.format("OrderDtlDStatisticsJob >>>>结束时间:" + ZxDateUtils.now(), this.parameter));
    }


    public boolean clearOrderEvaluationDAnalysis(Integer beforeDay){

        Calendar calendarStart =  Calendar.getInstance();
        calendarStart.add(Calendar.DATE,beforeDay);
        calendarStart.set(Calendar.HOUR_OF_DAY,0);
        calendarStart.set(Calendar.MINUTE,0);
        calendarStart.set(Calendar.SECOND,0);

        Calendar calendarEnd =  Calendar.getInstance();
        calendarEnd.add(Calendar.DATE,beforeDay);
        calendarEnd.set(Calendar.HOUR_OF_DAY,23);
        calendarEnd.set(Calendar.MINUTE,59);
        calendarEnd.set(Calendar.SECOND,59);

        OrderDtlD orderDtlD = new OrderDtlD();
        Integer statDt  = Integer.valueOf(DateUtil.formatToStr(new Date(calendarStart.getTime().getTime()),"yyyyMMdd"));
        orderDtlD.setStatDt(statDt);
        QueryWrapper<OrderDtlD> queryWrapper = new QueryWrapper<OrderDtlD>(orderDtlD);
        return orderDtlDService.remove(queryWrapper);
    }


    public boolean orderDtlDAnalysis(Integer beforeDay){
        Calendar calendarStart =  Calendar.getInstance();
        calendarStart.add(Calendar.DATE,beforeDay);
        calendarStart.set(Calendar.HOUR_OF_DAY,0);
        calendarStart.set(Calendar.MINUTE,0);
        calendarStart.set(Calendar.SECOND,0);

        Calendar calendarEnd =  Calendar.getInstance();
        calendarEnd.add(Calendar.DATE,beforeDay);
        calendarEnd.set(Calendar.HOUR_OF_DAY,23);
        calendarEnd.set(Calendar.MINUTE,59);
        calendarEnd.set(Calendar.SECOND,59);

        try {
            List<Map> orderDtlDAnalysis = orderDtlDService.orderDtlDAnalysis(calendarStart.getTime().getTime(),calendarEnd.getTime().getTime());
            log.info(JSON.toJSONString(orderDtlDAnalysis));

            List<OrderDtlD> orderDtlDAnalysisData =  new ArrayList<>();
            Integer statDt  = Integer.valueOf(DateUtil.formatToStr(new Date(calendarStart.getTime().getTime()),"yyyyMMdd"));
            for (int i = 0; i <orderDtlDAnalysis.size() ; i++) {
                Map map = orderDtlDAnalysis.get(i);
                map.put("statDt",statDt);
                OrderDtlD orderDtlD = new OrderDtlD(map);
                orderDtlDAnalysisData.add(orderDtlD);
            }
            Boolean flag = orderDtlDService.saveBatch(orderDtlDAnalysisData,orderDtlDAnalysisData.size());

        }catch (Throwable e){
            log.error(e.toString());
        	throw new InterfaceZxException("执行定时任务orderDtlDAnalysis失败");
        }

        return true;
    }


}
