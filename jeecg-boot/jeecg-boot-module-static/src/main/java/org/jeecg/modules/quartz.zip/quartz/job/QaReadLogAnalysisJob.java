package com.yewyw.module.quartz.job;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yewyw.module.qasystem.entity.QuestionIncmD;
import com.yewyw.module.qasystem.service.QuestionIncmDService;
import com.yewyw.util.date.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by DexSinis
 * 定时点击问答问题数据统计
 */
@Slf4j
public class QaReadLogAnalysisJob implements Job {

    private static final Integer beforeDay = 0;

    @Resource
    private QuestionIncmDService questionIncmDService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        log.error("---------------->>>>>>>calendarStart");
        this.clearAnalysis();
        // TODO: 2019-05-20 页面点击统计
        this.qaReadLogAnalysis();
        log.error("---------------->>>>>>>calendarEnd");

    }



    public boolean qaReadLogAnalysis(){
        Calendar calendarStart =  Calendar.getInstance();
        calendarStart.add(Calendar.DATE,beforeDay);
        calendarStart.set(Calendar.HOUR_OF_DAY,0);
        calendarStart.set(Calendar.MINUTE,0);
        calendarStart.set(Calendar.SECOND,0);

        Calendar calendarEnd =  Calendar.getInstance();
        calendarEnd.add(Calendar.DATE,beforeDay);
        calendarEnd.set(Calendar.HOUR_OF_DAY,23);
        calendarEnd.set(Calendar.MINUTE,59);
        calendarEnd.set(Calendar.SECOND,59);


        return  questionIncmDService.qaReadLogAnalysis(calendarStart.getTime().getTime(),calendarEnd.getTime().getTime());

//        return new PageAccessService().qaReadLogAnalysis(calendarStart.getTime().getTime(),calendarEnd.getTime().getTime());



    }


    public boolean clearAnalysis(){

        Calendar calendarStart =  Calendar.getInstance();
        calendarStart.add(Calendar.DATE,beforeDay);
        calendarStart.set(Calendar.HOUR_OF_DAY,0);
        calendarStart.set(Calendar.MINUTE,0);
        calendarStart.set(Calendar.SECOND,0);

        QuestionIncmD questionIncmD = new QuestionIncmD();
        Integer statDt  = Integer.valueOf(DateUtil.formatToStr(new Date(calendarStart.getTime().getTime()),"yyyyMMdd"));
        questionIncmD.setStatDt(statDt);
        QueryWrapper<QuestionIncmD> queryWrapper = new QueryWrapper<QuestionIncmD>(questionIncmD);
        questionIncmDService.remove(queryWrapper);
        return true;
    }


}