package com.yewyw.module.quartz.service.impl;

import java.util.List;

import com.yewyw.module.quartz.entity.QuartzJob;
import com.yewyw.module.quartz.mapper.QuartzJobMapper;
import com.yewyw.module.quartz.service.IQuartzJobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import javax.annotation.Resource;

/**
 * @Description: 定时任务在线管理
 * @author： DexSinis
 * @date：   2019-01-02
 * @version： V1.0
 */
@Service
public class QuartzJobServiceImpl extends ServiceImpl<QuartzJobMapper, QuartzJob> implements IQuartzJobService {
	@Resource
	private QuartzJobMapper quartzJobMapper;

	@Override
	public List<QuartzJob> findByJobClassName(String jobClassName) {
		return quartzJobMapper.findByJobClassName(jobClassName);
	}

}
