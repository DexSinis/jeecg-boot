package org.jeecg.modules.statistics.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 渠道关注时统计表，存储每日偶数时点关注数据。每偶数整点增量统计。 前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-06-11
 */
@Controller
@RequestMapping("/chnlAttentionH")
public class ChnlAttentionHController {

}

