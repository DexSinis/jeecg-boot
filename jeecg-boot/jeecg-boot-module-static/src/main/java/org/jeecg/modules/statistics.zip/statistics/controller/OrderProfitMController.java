package org.jeecg.modules.statistics.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 工单量及收益日统计表 前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-07-19
 */
@Controller
@RequestMapping("/orderProfitM")
public class OrderProfitMController {

}

