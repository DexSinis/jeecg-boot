package org.jeecg.modules.statistics.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 用户工单日全量表，保存累计到统计当天用户工单量等信息。 前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-06-04
 */
@Controller
@RequestMapping("/persUserOrderD")
public class PersUserOrderDController {

}

