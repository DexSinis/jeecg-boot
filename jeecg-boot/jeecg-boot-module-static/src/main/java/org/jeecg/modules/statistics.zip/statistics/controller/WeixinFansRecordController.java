package org.jeecg.modules.statistics.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-06-10
 */
@Controller
@RequestMapping("/weixinFansRecord")
public class WeixinFansRecordController {

}

