package org.jeecg.modules.sims.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 网易云信账号  前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-09-26
 */
@Controller
@RequestMapping("/simsTokenVersion")
public class SimsTokenVersionController {

}

