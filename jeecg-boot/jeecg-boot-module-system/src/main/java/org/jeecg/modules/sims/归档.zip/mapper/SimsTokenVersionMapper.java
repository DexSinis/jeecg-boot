package org.jeecg.modules.sims.mapper;

import org.jeecg.modules.sims.entity.SimsTokenVersion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 网易云信账号  Mapper 接口
 * </p>
 *
 * @author DexSinis
 * @since 2019-09-26
 */
public interface SimsTokenVersionMapper extends BaseMapper<SimsTokenVersion> {

}
