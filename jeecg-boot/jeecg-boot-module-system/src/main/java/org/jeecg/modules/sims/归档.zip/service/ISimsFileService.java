package org.jeecg.modules.sims.service;

import org.jeecg.modules.sims.entity.SimsFile;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程资料表 服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-19
 */
public interface ISimsFileService extends IService<SimsFile> {

}
