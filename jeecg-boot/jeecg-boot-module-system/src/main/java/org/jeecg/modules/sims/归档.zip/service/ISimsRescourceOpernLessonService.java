package org.jeecg.modules.sims.service;

import org.jeecg.modules.sims.entity.SimsRescourceOpernLesson;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 资料课程关系 服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-13
 */
public interface ISimsRescourceOpernLessonService extends IService<SimsRescourceOpernLesson> {

}
