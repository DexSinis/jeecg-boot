package org.jeecg.modules.sims.service;

import org.jeecg.modules.sims.entity.SimsRescourceOpernStudent;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 资料学生关系 服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-12
 */
public interface ISimsRescourceOpernStudentService extends IService<SimsRescourceOpernStudent> {

}
