//package org.jeecg.modules.sims.service.impl;
//
//import org.jeecg.modules.sims.entity.SimsRescourceStudent;
//import org.jeecg.modules.sims.mapper.SimsRescourceStudentMapper;
//import org.jeecg.modules.sims.service.ISimsRescourceStudentService;
//import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//import org.springframework.stereotype.Service;
//
///**
// * <p>
// * 资料学生关系 服务实现类
// * </p>
// *
// * @author DexSinis
// * @since 2019-08-10
// */
//@Service
//public class SimsRescourceStudentServiceImpl extends ServiceImpl<SimsRescourceStudentMapper, SimsRescourceStudent> implements ISimsRescourceStudentService {
//
//}
