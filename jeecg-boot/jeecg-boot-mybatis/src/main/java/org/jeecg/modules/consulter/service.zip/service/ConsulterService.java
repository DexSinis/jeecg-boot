package com.yewyw.module.consulter.service;

import com.yewyw.module.consulter.entity.Consulter;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 咨询者、病人、粉丝 服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-05-14
 */
public interface ConsulterService extends IService<Consulter> {

    Map findConsulterIdsByLoginTime(Integer lastTime);

    List<Map> findPersUserDList(String consulterIds);

    List<Map> findOrderCountList(String consulterIds);
}
