package com.yewyw.module.consulter.service.impl;

import com.yewyw.module.consulter.entity.ConsulterOrder;
import com.yewyw.module.consulter.mapper.ConsulterOrderMapper;
import com.yewyw.module.consulter.service.ConsultService;
import com.yewyw.util.response.ServiceResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yujianqiang on 2019/3/25.
 */
@Service
public class ConsultServiceImpl implements ConsultService {

    @Autowired
    private ConsulterOrderMapper consulterOrderMapper;

    @Override
    public ServiceResult getOrderStatus(Integer orderId) {
        ConsulterOrder consulterOrder = consulterOrderMapper.getOrderStatusById(orderId);
        Map<String, Object> map = new HashMap<>();
        if (consulterOrder != null) {
            map.put("orderId", consulterOrder.getId());
            map.put("status", consulterOrder.getStatus());
            map.put("server_status", consulterOrder.getServerStatus());
        }
        return ServiceResult.buildSuccess(map);
    }
}
