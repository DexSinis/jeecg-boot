package com.yewyw.module.consulter.service.impl;

import com.yewyw.module.consulter.entity.Consulter;
import com.yewyw.module.consulter.mapper.ConsulterMapper;
import com.yewyw.module.consulter.service.ConsulterService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 咨询者、病人、粉丝 服务实现类
 * </p>
 *
 * @author DexSinis
 * @since 2019-05-14
 */
@Service
public class ConsulterServiceImpl extends ServiceImpl<ConsulterMapper, Consulter> implements ConsulterService {

    @Resource
    private ConsulterMapper consulterMapper;

    @Override
    public Map findConsulterIdsByLoginTime(Integer lastTime) {

        return consulterMapper.getConsulterIdsByLoginTime(lastTime);
    }

    @Override
    public List<Map> findPersUserDList(String consulterIds) {
        return consulterMapper.getPersUserDList(consulterIds);
    }

    @Override
    public List<Map> findOrderCountList(String consulterIds) {
        return consulterMapper.getOrderCountList(consulterIds);
    }
}
