package org.jeecg.modules.order.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * H5支付中间表 前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-10-22
 */
@Controller
@RequestMapping("/payTempOrder")
public class PayTempOrderController {

}

