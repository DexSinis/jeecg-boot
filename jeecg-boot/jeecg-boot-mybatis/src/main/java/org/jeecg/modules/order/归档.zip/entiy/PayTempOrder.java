//package org.jeecg.modules.order.entiy;
//
//import java.math.BigDecimal;
//import com.baomidou.mybatisplus.annotation.IdType;
//import com.baomidou.mybatisplus.extension.activerecord.Model;
//import com.baomidou.mybatisplus.annotation.TableId;
//import java.time.LocalDateTime;
//import java.io.Serializable;
//import java.util.Date;
//
///**
// * <p>
// * H5支付中间表
// * </p>
// *
// * @author DexSinis
// * @since 2019-07-10
// */
//public class PayTempOrder extends Model<PayTempOrder> {
//
//    private static final long serialVersionUID = 1L;
//
//    @TableId(value = "id", type = IdType.AUTO)
//    private Integer id;
//
//    private Integer consulterId;
//
//    private String label;
//
//    private String problem;
//
//    private Integer consulteType;
//
//    private Integer isdefault;
//
//    private String preorder;
//
//    private Integer labelid;
//
//    private String babyid;
//
//    private String flag;
//
//    private Integer status;
//
//    private Date createTime;
//
//    private String payType;
//
//    private String customerId;
//
//    private String busiTradeNo;
//
//    private Date updateTime;
//
//    private Integer resourceInstId;
//
//    private BigDecimal discountCharge;
//
//    private String clickPrama;
//
//    private Integer orderId;
//
//    private String allSrc;
//
//    private Integer isPayed;
//
//    private BigDecimal fee;
//
//    private String goodId;
//
//    private BigDecimal cusAttrFee;
//
//    /**
//     * 非明星医生id，指定非明星医生咨询时才记录本字段
//     */
//    private Integer commonCustomerId;
//
//    private String mobileInfo;
//
//    private String bMark;
//
//    /**
//     * 工单类型编码，0：快速咨询工单 1：明星医生工单 2：营养师工单 3：心理咨询工单
//     */
//    private Integer orderType;
//
//    /**
//     * 咨询问题主题编码，0：儿科问题 1：妇科问题 2：营养师咨询 3：心理咨询
//
//     */
//    private Integer questionTopicCode;
//
//    /**
//     * 首次分发类型：
//0：定向分发  1：非定向分发
//     */
//    private Integer firstDistributeType;
//
//
//    public Integer getId() {
//        return id;
//    }
//
//    public void setId(Integer id) {
//        this.id = id;
//    }
//
//    public Integer getConsulterId() {
//        return consulterId;
//    }
//
//    public void setConsulterId(Integer consulterId) {
//        this.consulterId = consulterId;
//    }
//
//    public String getLabel() {
//        return label;
//    }
//
//    public void setLabel(String label) {
//        this.label = label;
//    }
//
//    public String getProblem() {
//        return problem;
//    }
//
//    public void setProblem(String problem) {
//        this.problem = problem;
//    }
//
//    public Integer getConsulteType() {
//        return consulteType;
//    }
//
//    public void setConsulteType(Integer consulteType) {
//        this.consulteType = consulteType;
//    }
//
//    public Integer getIsdefault() {
//        return isdefault;
//    }
//
//    public void setIsdefault(Integer isdefault) {
//        this.isdefault = isdefault;
//    }
//
//    public String getPreorder() {
//        return preorder;
//    }
//
//    public void setPreorder(String preorder) {
//        this.preorder = preorder;
//    }
//
//    public Integer getLabelid() {
//        return labelid;
//    }
//
//    public void setLabelid(Integer labelid) {
//        this.labelid = labelid;
//    }
//
//    public String getBabyid() {
//        return babyid;
//    }
//
//    public void setBabyid(String babyid) {
//        this.babyid = babyid;
//    }
//
//    public String getFlag() {
//        return flag;
//    }
//
//    public void setFlag(String flag) {
//        this.flag = flag;
//    }
//
//    public Integer getStatus() {
//        return status;
//    }
//
//    public void setStatus(Integer status) {
//        this.status = status;
//    }
//
//    public Date getCreateTime() {
//        return createTime;
//    }
//
//    public void setCreateTime(Date createTime) {
//        this.createTime = createTime;
//    }
//
//    public String getPayType() {
//        return payType;
//    }
//
//    public void setPayType(String payType) {
//        this.payType = payType;
//    }
//
//    public String getCustomerId() {
//        return customerId;
//    }
//
//    public void setCustomerId(String customerId) {
//        this.customerId = customerId;
//    }
//
//    public String getBusiTradeNo() {
//        return busiTradeNo;
//    }
//
//    public void setBusiTradeNo(String busiTradeNo) {
//        this.busiTradeNo = busiTradeNo;
//    }
//
//    public Date getUpdateTime() {
//        return updateTime;
//    }
//
//    public void setUpdateTime(Date updateTime) {
//        this.updateTime = updateTime;
//    }
//
//    public Integer getResourceInstId() {
//        return resourceInstId;
//    }
//
//    public void setResourceInstId(Integer resourceInstId) {
//        this.resourceInstId = resourceInstId;
//    }
//
//    public BigDecimal getDiscountCharge() {
//        return discountCharge;
//    }
//
//    public void setDiscountCharge(BigDecimal discountCharge) {
//        this.discountCharge = discountCharge;
//    }
//
//    public String getClickPrama() {
//        return clickPrama;
//    }
//
//    public void setClickPrama(String clickPrama) {
//        this.clickPrama = clickPrama;
//    }
//
//    public Integer getOrderId() {
//        return orderId;
//    }
//
//    public void setOrderId(Integer orderId) {
//        this.orderId = orderId;
//    }
//
//    public String getAllSrc() {
//        return allSrc;
//    }
//
//    public void setAllSrc(String allSrc) {
//        this.allSrc = allSrc;
//    }
//
//    public Integer getIsPayed() {
//        return isPayed;
//    }
//
//    public void setIsPayed(Integer isPayed) {
//        this.isPayed = isPayed;
//    }
//
//    public BigDecimal getFee() {
//        return fee;
//    }
//
//    public void setFee(BigDecimal fee) {
//        this.fee = fee;
//    }
//
//    public String getGoodId() {
//        return goodId;
//    }
//
//    public void setGoodId(String goodId) {
//        this.goodId = goodId;
//    }
//
//    public BigDecimal getCusAttrFee() {
//        return cusAttrFee;
//    }
//
//    public void setCusAttrFee(BigDecimal cusAttrFee) {
//        this.cusAttrFee = cusAttrFee;
//    }
//
//    public Integer getCommonCustomerId() {
//        return commonCustomerId;
//    }
//
//    public void setCommonCustomerId(Integer commonCustomerId) {
//        this.commonCustomerId = commonCustomerId;
//    }
//
//    public String getMobileInfo() {
//        return mobileInfo;
//    }
//
//    public void setMobileInfo(String mobileInfo) {
//        this.mobileInfo = mobileInfo;
//    }
//
//    public String getbMark() {
//        return bMark;
//    }
//
//    public void setbMark(String bMark) {
//        this.bMark = bMark;
//    }
//
//    public Integer getOrderType() {
//        return orderType;
//    }
//
//    public void setOrderType(Integer orderType) {
//        this.orderType = orderType;
//    }
//
//    public Integer getQuestionTopicCode() {
//        return questionTopicCode;
//    }
//
//    public void setQuestionTopicCode(Integer questionTopicCode) {
//        this.questionTopicCode = questionTopicCode;
//    }
//
//    public Integer getFirstDistributeType() {
//        return firstDistributeType;
//    }
//
//    public void setFirstDistributeType(Integer firstDistributeType) {
//        this.firstDistributeType = firstDistributeType;
//    }
//
//    @Override
//    protected Serializable pkVal() {
//        return this.id;
//    }
//
//    @Override
//    public String toString() {
//        return "PayTempOrder{" +
//        "id=" + id +
//        ", consulterId=" + consulterId +
//        ", label=" + label +
//        ", problem=" + problem +
//        ", consulteType=" + consulteType +
//        ", isdefault=" + isdefault +
//        ", preorder=" + preorder +
//        ", labelid=" + labelid +
//        ", babyid=" + babyid +
//        ", flag=" + flag +
//        ", status=" + status +
//        ", createTime=" + createTime +
//        ", payType=" + payType +
//        ", customerId=" + customerId +
//        ", busiTradeNo=" + busiTradeNo +
//        ", updateTime=" + updateTime +
//        ", resourceInstId=" + resourceInstId +
//        ", discountCharge=" + discountCharge +
//        ", clickPrama=" + clickPrama +
//        ", orderId=" + orderId +
//        ", allSrc=" + allSrc +
//        ", isPayed=" + isPayed +
//        ", fee=" + fee +
//        ", goodId=" + goodId +
//        ", cusAttrFee=" + cusAttrFee +
//        ", commonCustomerId=" + commonCustomerId +
//        ", mobileInfo=" + mobileInfo +
//        ", bMark=" + bMark +
//        ", orderType=" + orderType +
//        ", questionTopicCode=" + questionTopicCode +
//        ", firstDistributeType=" + firstDistributeType +
//        "}";
//    }
//}
