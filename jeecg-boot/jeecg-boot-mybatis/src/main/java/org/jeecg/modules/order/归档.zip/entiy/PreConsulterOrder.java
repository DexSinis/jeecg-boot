//package org.jeecg.modules.order.entiy;
//
//import com.baomidou.mybatisplus.annotation.TableId;
//import com.baomidou.mybatisplus.extension.activerecord.Model;
//import java.io.Serializable;
//
///**
// * <p>
// *
// * </p>
// *
// * @author DexSinis
// * @since 2019-07-09
// */
//public class PreConsulterOrder extends Model<PreConsulterOrder> {
//
//    private static final long serialVersionUID = 1L;
//
//    /**
//     *  临时表id
//     */
//    @TableId(value = "pay_temp_order_id")
//    private Integer payTempOrderId;
//
//    /**
//     * 医生ID
//     */
//    private Integer customerId;
//
//    /**
//     * 用户ID
//     */
//    private Integer consulterId;
//
//    /**
//     * 工单ID，ID生成后回填。
//     */
//    private Integer orderId;
//
//    /**
//     * 是否已经填写完信息并且已经生成工单 0未生成工单
//     */
//    private Integer orderStatus;
//
//    /**
//     * 妈妈档案，宝宝档案
//     */
//    private Integer consulterType;
//
//    /**
//     * 跳转到页面的时候 创建一个档案记录(这个记录在点击确定的时候绑定到对应的consulter)
//     */
//    private String babyId;
//
//    private Long createTime;
//
//    /**
//     * 是否新创建档案信息
//     */
//    private Integer isNew;
//
//    private Integer isComplete;
//
//
//    public Integer getPayTempOrderId() {
//        return payTempOrderId;
//    }
//
//    public void setPayTempOrderId(Integer payTempOrderId) {
//        this.payTempOrderId = payTempOrderId;
//    }
//
//    public Integer getCustomerId() {
//        return customerId;
//    }
//
//    public void setCustomerId(Integer customerId) {
//        this.customerId = customerId;
//    }
//
//    public Integer getConsulterId() {
//        return consulterId;
//    }
//
//    public void setConsulterId(Integer consulterId) {
//        this.consulterId = consulterId;
//    }
//
//    public Integer getOrderId() {
//        return orderId;
//    }
//
//    public void setOrderId(Integer orderId) {
//        this.orderId = orderId;
//    }
//
//    public Integer getOrderStatus() {
//        return orderStatus;
//    }
//
//    public void setOrderStatus(Integer orderStatus) {
//        this.orderStatus = orderStatus;
//    }
//
//    public Integer getConsulterType() {
//        return consulterType;
//    }
//
//    public void setConsulterType(Integer consulterType) {
//        this.consulterType = consulterType;
//    }
//
//    public String getBabyId() {
//        return babyId;
//    }
//
//    public void setBabyId(String babyId) {
//        this.babyId = babyId;
//    }
//
//    public Long getCreateTime() {
//        return createTime;
//    }
//
//    public void setCreateTime(Long createTime) {
//        this.createTime = createTime;
//    }
//
//    public Integer getIsNew() {
//        return isNew;
//    }
//
//    public void setIsNew(Integer isNew) {
//        this.isNew = isNew;
//    }
//
//    public Integer getIsComplete() {
//        return isComplete;
//    }
//
//    public void setIsComplete(Integer isComplete) {
//        this.isComplete = isComplete;
//    }
//
//    @Override
//    protected Serializable pkVal() {
//        return this.payTempOrderId;
//    }
//
//    @Override
//    public String toString() {
//        return "PreConsulterOrder{" +
//        "payTempOrderId=" + payTempOrderId +
//        ", customerId=" + customerId +
//        ", consulterId=" + consulterId +
//        ", orderId=" + orderId +
//        ", orderStatus=" + orderStatus +
//        ", consulterType=" + consulterType +
//        ", babyId=" + babyId +
//        ", createTime=" + createTime +
//        ", isNew=" + isNew +
//        ", isComplete=" + isComplete +
//        "}";
//    }
//}
