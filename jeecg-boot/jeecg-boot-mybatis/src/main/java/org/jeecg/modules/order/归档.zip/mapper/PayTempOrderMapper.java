package org.jeecg.modules.order.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.jeecg.modules.order.entiy.PayTempOrder;

/**
 * <p>
 * H5支付中间表 Mapper 接口
 * </p>
 *
 * @author DexSinis
 * @since 2019-07-10
 */
public interface PayTempOrderMapper extends BaseMapper<PayTempOrder> {

}
