package org.jeecg.modules.order.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.jeecg.modules.order.entiy.PreConsulterOrder;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author DexSinis
 * @since 2019-07-09
 */
public interface PreConsulterOrderMapper extends BaseMapper<PreConsulterOrder> {

}
