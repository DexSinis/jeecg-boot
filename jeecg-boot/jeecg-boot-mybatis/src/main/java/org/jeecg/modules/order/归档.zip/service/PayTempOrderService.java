package org.jeecg.modules.order.service;

import org.jeecg.modules.order.entity.PayTempOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * H5支付中间表 服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-10-22
 */
public interface PayTempOrderService extends IService<PayTempOrder> {

}
