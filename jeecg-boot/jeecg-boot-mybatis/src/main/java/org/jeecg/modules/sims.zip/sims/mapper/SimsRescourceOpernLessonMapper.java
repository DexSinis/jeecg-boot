package org.jeecg.modules.sims.mapper;

import org.jeecg.modules.sims.entity.SimsRescourceOpernLesson;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 资料课程关系 Mapper 接口
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-13
 */
public interface SimsRescourceOpernLessonMapper extends BaseMapper<SimsRescourceOpernLesson> {

}
