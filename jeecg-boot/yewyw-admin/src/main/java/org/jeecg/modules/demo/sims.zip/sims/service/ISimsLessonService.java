//package org.jeecg.modules.demo.sims.service;
//
//import org.jeecg.modules.demo.sims.entity.SimsLesson;
//import com.baomidou.mybatisplus.extension.service.IService;
//
///**
// * @Description: 课程列表
// * @Author: jeecg-boot
// * @Date:   2019-08-21
// * @Version: V1.0
// */
//public interface ISimsLessonService extends IService<SimsLesson> {
//
//}
