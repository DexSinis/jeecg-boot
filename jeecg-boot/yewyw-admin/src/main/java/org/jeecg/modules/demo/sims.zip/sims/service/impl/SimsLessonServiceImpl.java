//package org.jeecg.modules.demo.sims.service.impl;
//
//import org.jeecg.modules.demo.sims.entity.SimsLesson;
//import org.jeecg.modules.demo.sims.mapper.SimsLessonMapper;
//import org.jeecg.modules.demo.sims.service.ISimsLessonService;
//import org.springframework.stereotype.Service;
//
//import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//
///**
// * @Description: 课程列表
// * @Author: jeecg-boot
// * @Date:   2019-08-21
// * @Version: V1.0
// */
//@Service
//public class SimsLessonServiceImpl extends ServiceImpl<SimsLessonMapper, SimsLesson> implements ISimsLessonService {
//
//}
