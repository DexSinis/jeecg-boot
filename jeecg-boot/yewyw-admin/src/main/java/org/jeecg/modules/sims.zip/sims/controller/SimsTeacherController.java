package org.jeecg.modules.sims.controller;


import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 教师  前端控制器
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
@RestController
@Api(tags="教师接口")
@RequestMapping("/simsTeacher")
public class SimsTeacherController {

}

