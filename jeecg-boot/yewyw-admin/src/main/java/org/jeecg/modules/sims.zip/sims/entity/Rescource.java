package org.jeecg.modules.sims.entity;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.jeecg.common.system.base.entity.JeecgEntity;

import java.io.Serializable;

/**
 * <p>
 * 系统资源
 * </p>
 *
 * @author wangl
 * @since 2018-01-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Rescource  extends JeecgEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 文件名称
     */
	private String fileName;
    /**
     * 来源
     */
	private String source;
    /**
     * 资源网络地址
     */
	private String webUrl;
    /**
     * 文件标识
     */
	private String hash;
    /**
     * 文件大小
     */
	private String fileSize;
    /**
     * 文件类型
     */
	private String fileType;

	private String originalNetUrl;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getWebUrl() {
		return webUrl;
	}

	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getOriginalNetUrl() {
		return originalNetUrl;
	}

	public void setOriginalNetUrl(String originalNetUrl) {
		this.originalNetUrl = originalNetUrl;
	}

	@Override
	public String toString() {
		return "Rescource{" +
			", fileName=" + fileName +
			", source=" + source +
			", webUrl=" + webUrl +
			", hash=" + hash +
			", fileSize=" + fileSize +
			", fileType=" + fileType +
			", originalNetUrl=" + originalNetUrl +
			"}";
	}
}
