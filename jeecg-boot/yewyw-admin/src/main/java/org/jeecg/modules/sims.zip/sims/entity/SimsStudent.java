package org.jeecg.modules.sims.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import java.util.Map;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.jeecg.common.system.base.entity.JeecgEntity;
import org.jeecg.common.util.oConvertUtils;

/**
 * <p>
 * 学生 
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="学生对象", description="学生对象信息")
@TableName("sims_student")
public class SimsStudent extends JeecgEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 所在学院
     */
    @ApiModelProperty(value = "所在学院")
    private String collegeId;

    /**
     * 所在班级
     */
    @ApiModelProperty(value = "所在班级")
    private String classId;

    /**
     * 学号
     */
    @ApiModelProperty(value = "学号")
    private String id;

    /**
     * 对接平台账号ID(如腾讯)
     */
    @ApiModelProperty(value = "对接平台账号ID(如腾讯)")
    private String simsid;

    /**
     * 对接平台密码(如腾讯)
     */
    @ApiModelProperty(value = "对接平台密码(如腾讯urlSig)")
    private String simsPassword;

    /**
     * 学生姓名
     */
    @ApiModelProperty(value = "学生姓名")
    private String name;

    /**
     * 身份证号
     */
    @ApiModelProperty(value = "身份证号")
    private String idCardNo;

    /**
     * 英文名
     */
    @ApiModelProperty(value = "英文名")
    private String engName;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String mobilePhone;

    /**
     * 密码
     */
    @ApiModelProperty(value = "密码")
    private String password;

    /**
     * 性别
     */
    @ApiModelProperty(value = "性别")
    private String gender;

    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private LocalDate birth;

    /**
     * 头像
     */
    @ApiModelProperty(value = "头像")
    private String avatar;

    /**
     * 身高
     */
    @ApiModelProperty(value = "身高")
    private BigDecimal height;

    /**
     * 体重
     */
    @ApiModelProperty(value = "体重")
    private BigDecimal weight;

    /**
     * 名族
     */
    @ApiModelProperty(value = "名族")
    private String nation;

    /**
     * 政治面貌
     */
    @ApiModelProperty(value = "政治面貌")
    private String political;

    /**
     * 婚姻状况
     */
    @ApiModelProperty(value = "婚姻状况")
    private String marital;

    /**
     * 籍贯（省） 国标行政区域代码-省级
     */
    @ApiModelProperty(value = "籍贯（省）")
    private String domicilePlaceProvince;

    /**
     * 籍贯（市） 国标行政区域代码-市级
     */
    @ApiModelProperty(value = " 籍贯（市）")
    private String domicilePlaceCity;

    /**
     * 户籍地址
     */
    @ApiModelProperty(value = "户籍地址")
    private String domicilePlaceAddress;

    /**
     * 爱好
     */
    @ApiModelProperty(value = "爱好")
    private String hobby;

    /**
     * 简要介绍
     */
    @ApiModelProperty(value = "简要介绍")
    private String intro;

    /**
     * 居住地址
     */
    @ApiModelProperty(value = "居住地址")
    private String presentAddress;

    /**
     * 电子邮件
     */
    @ApiModelProperty(value = "电子邮件")
    private String email;

    /**
     * 入学日期
     */
    @ApiModelProperty(value = "入学日期")
    private LocalDate entryDate;

    /**
     * 状态
     */
    @ApiModelProperty(value = "状态")
    private String status;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updateTime;

    /**
     * 是否在线
     */
    @ApiModelProperty(value = "是否在线")
    private Integer online;


    public SimsStudent() {
    }

    public SimsStudent(Map map) {
        this.setMobilePhone(oConvertUtils.getString(map.get("mobilePhone"),""));
        this.setPassword(oConvertUtils.getString(map.get("password"),""));
    }
}
