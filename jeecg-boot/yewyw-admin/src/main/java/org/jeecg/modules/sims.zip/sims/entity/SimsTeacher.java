package org.jeecg.modules.sims.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.jeecg.common.system.base.entity.JeecgEntity;

/**
 * <p>
 * 教师 
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class SimsTeacher extends JeecgEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 所在学院
     */
    private String collegeId;

    /**
     * 教师编号
     */
    private String id;

    /**
     * 姓名
     */
    private String name;

    /**
     * 手机号
     */
    private String mobilePhone;

    /**
     * 密码
     */
    private String password;

    /**
     * 对接平台账号ID(如腾讯)
     */
    private String simsid;

    /**
     * 对接平台密码(如腾讯urlSig)
     */
    private String simsPassword;

    /**
     * 性别
     */
    private String gender;

    /**
     * 出生日期
     */
    private LocalDate birth;

    /**
     * 介绍
     */
    private String intro;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 是否在线
     */
    @ApiModelProperty(value = "是否在线")
    private Integer online;

    public SimsTeacher(Map map) {
    }
}
