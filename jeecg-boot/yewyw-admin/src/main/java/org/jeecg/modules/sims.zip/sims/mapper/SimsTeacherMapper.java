package org.jeecg.modules.sims.mapper;

import org.jeecg.modules.sims.entity.SimsTeacher;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 教师  Mapper 接口
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
public interface SimsTeacherMapper extends BaseMapper<SimsTeacher> {

}
