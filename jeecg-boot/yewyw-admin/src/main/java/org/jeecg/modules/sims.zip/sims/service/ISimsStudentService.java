package org.jeecg.modules.sims.service;

import org.jeecg.modules.sims.entity.SimsStudent;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 学生  服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
public interface ISimsStudentService extends IService<SimsStudent> {

}
