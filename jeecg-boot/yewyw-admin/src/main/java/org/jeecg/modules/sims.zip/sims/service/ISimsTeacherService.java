package org.jeecg.modules.sims.service;

import org.jeecg.modules.sims.entity.SimsTeacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 教师  服务类
 * </p>
 *
 * @author DexSinis
 * @since 2019-08-03
 */
public interface ISimsTeacherService extends IService<SimsTeacher> {

}
